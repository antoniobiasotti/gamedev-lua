function love.conf(t)
  t.window.title = "WTT2025 - Desenvolvimento de Jogos 2D com a Linguagem Lua"
  t.window.width = 800
  t.window.height = 600
  t.window.resizable = false
  --t.window.borderless = true
  --t.console = true
end
