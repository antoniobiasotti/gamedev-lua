local screenWidth, screenHeight = love.graphics.getDimensions()

local wtt = {}

wtt.colors = {
  background = { 0.1, 0.1, 0.1 },
  white = { 0.9, 0.9, 0.9 },
  yellow = { 1.0, 0.8, 0.0 },
  green = { 0.0, 0.9, 0.0 }
}

-- PLAYER (PADDLE) -------------------------------------------------------------
local function createPlayer(params)
  local player = {
  }
  
  player.update = function(self, dt)
  end
  
  player.draw = function(self)
  end
  
  player.incScore = function(self)
  end
  
  return player
end

-- BALL ------------------------------------------------------------------------
local function createBall(params)
  local ball = {
  }
  
  function ball:reset() -- equivalente a: ball.reset = function(self)
  end
  
  function ball:update(dt) -- equivalente a: ball.update = function(self, dt)
  end
  
  function ball:draw() -- equivalente a: ball.draw = function(self)
  end
  
  return ball
end

-- GAME MANAGER ----------------------------------------------------------------
local function createGameManager()
  love.graphics.setBackgroundColor(wtt.colors.background)

  local myFont = love.graphics.newFont("assets/PressStart2P.ttf", 14)
  love.graphics.setFont(myFont)

  local halfScreenWidth = screenWidth * 0.5
  local gameManager = {}
  
  local paddleOffset = 10
  local paddleWidth = 10
  local paddleHeight = 100
  local paddleVelocity = 400
  gameManager.players = {
  }
  
  local ballWidth = 10
  local ballHeight = 10
  local ballVX = 400
  local ballVY = 400
  gameManager.ball = createBall({
  })
  
  function gameManager:update(dt)
  end
  
  function gameManager:draw()
  end
  
  function gameManager:drawScore()
  end
  
  function gameManager:checkScore()
  end

  function gameManager:checkCollisionBetween(obj1, obj2)
  end

  return gameManager
end

wtt.createGameManager = createGameManager

return wtt
