local wtt = require("wtt")

function love.load()
  gameManager = wtt.createGameManager()
end

function love.update(dt)
  gameManager:update(dt)
end

function love.draw()
  gameManager:draw()
end
