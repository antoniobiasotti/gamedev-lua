function love.load()
  msg = "LMB para reproduzir áudio, RMB para parar reprodução."
  myAudio = love.audio.newSource("assets/audio.ogg", "static")
end

function love.mousepressed(x, y, button, istouch, presses)
  if button == 1 and not myAudio:isPlaying() then
    myAudio:play()
  elseif button == 2 and myAudio:isPlaying() then
    myAudio:stop()
  end
end

function love.draw()
  love.graphics.print(msg, 20, 20)
end
