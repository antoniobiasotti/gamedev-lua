function love.draw()
  love.graphics.setColor(1.0, 0.0, 0.0, 1.0)
  love.graphics.rectangle("fill", 20, 20, 50, 100)
  
  love.graphics.setColor(0.0, 1.0, 0.0, 1.0)
  love.graphics.rectangle("line", 20, 20, 50, 100)
  --love.graphics.rectangle("line", 200, 300, 150, 70)
  
  love.graphics.setColor(0.0, 0.0, 1.0, 1.0)
  love.graphics.circle("line", 400, 500, 30)
  
  love.graphics.setColor(1.0, 0.0, 1.0, 1.0)
  love.graphics.circle("fill", 600, 200, 100)
  
  love.graphics.setColor(1.0, 1.0, 0.0, 1.0)
  love.graphics.ellipse("fill", 300, 50, 100, 25)
  
  love.graphics.setColor(1.0, 0.0, 1.0, 0.25)
  love.graphics.ellipse("fill", 350, 80, 50, 25)
  
  love.graphics.setColor(1.0, 1.0, 1.0, 1.0)
  love.graphics.line(0, 0, 800, 600)
end
