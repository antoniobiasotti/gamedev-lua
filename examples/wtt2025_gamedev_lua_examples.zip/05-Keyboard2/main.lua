function love.load()
  msg = "horizontal: nenhum"
end

function love.keypressed(key, scancode, isrepeat)
  if key == "escape" then
    love.event.quit()
  elseif key == "left" or key == "a" then
    msg = "horizontal: esquerda"
  elseif key == "right" or key == "d" then
    msg = "horizontal: direita"
  end
end

function love.keyreleased(key, scancode)
  msg = "horizontal: nenhum"
end

function love.draw()
  love.graphics.print(msg, 20, 20)
end
