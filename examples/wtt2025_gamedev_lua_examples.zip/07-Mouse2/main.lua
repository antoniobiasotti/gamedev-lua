function love.load()
  msg1 = ""
  msg2 = ""
  msg3 = ""
end

function love.mousemoved(x, y, dx, dy, istouch)
  msg1 = "mouse(" .. x .. ", " .. y .. ")"
end

function love.mousepressed(x, y, button, istouch, presses)
  msg2 = "botão pressionado: " .. button
end

function love.mousereleased(x, y, button, istouch, presses)
  msg2 = "botão liberado: " .. button
end

function love.wheelmoved(x, y)
  msg3 = "scroll(" .. x .. ", " .. y .. ")"
end

function love.draw()
  love.graphics.print(msg1, 20, 20)
  love.graphics.print(msg2, 20, 40)
  love.graphics.print(msg3, 20, 60)
end
