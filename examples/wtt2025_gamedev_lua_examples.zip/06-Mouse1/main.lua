function love.load()
  msg = ""
end

function love.update(dt)
  msg = "mouse(" .. love.mouse.getX() .. ", "
    .. love.mouse.getY() .. ")\nbotão pressionado: "
  if love.mouse.isDown(1) then
    msg = msg .. "esquerdo"
  elseif love.mouse.isDown(2) then
    msg = msg .. "direito"
  elseif love.mouse.isDown(3) then
    msg = msg .. "meio"
  else
    msg = msg .. "nenhum"
  end
end

function love.draw()
  love.graphics.print(msg, 20, 20)
end
