function love.load()
  msg = ""
end

function love.update(dt)
  msg = "horizontal: "
  if love.keyboard.isDown("left", "a") then
    msg = msg .. "esquerda"
  elseif love.keyboard.isDown("right", "d") then
    msg = msg .. "direita"
  else
    msg = msg .. "nenhum"
  end
end

function love.draw()
  love.graphics.print(msg, 20, 20)
end
