function love.load()
  msg = "Hello, LÖVE!"
  
  local myFont = love.graphics.newFont("assets/PressStart2P.ttf", 20)
  love.graphics.setFont(myFont)
end

function love.draw()
  love.graphics.print(msg, 20, 20)
end
