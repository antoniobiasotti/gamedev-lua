function love.load()
  myImage = love.graphics.newImage("assets/tiny_ship5.png")
end

function love.draw()
  love.graphics.draw(myImage, 50, 70)
end
